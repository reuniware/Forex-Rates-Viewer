﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForexRatesViewer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Logger logger = new Logger();
        private void Form1_Load(object sender, EventArgs e)
        {
            logger.setTxtLog(txtLog);
            log("Main: Application Start (HttpToSqlServer)");

            IPAddress[] ipAddresses = Dns.GetHostAddresses(Dns.GetHostName());
            foreach (IPAddress ipAddress in ipAddresses)
            {
                log("Local IP Address = " + ipAddress.ToString());
            }

            Thread serverThread = new Thread(ServerThread);
            serverThread.Start();
        }

        private HttpListener listener;
        int listeningPort = 9090;
        private void ServerThread()
        {
            listener = new HttpListener();
            string[] prefixes = new string[] { "http://*:" + listeningPort + "/send_data/" };
            foreach (string s in prefixes) { listener.Prefixes.Add(s); }

            try
            {
                listener.Start();
            }
            catch (Exception ex)
            {
                log("(ServerThread) Impossible de démarrer le serveur d'écoute des connexions clients : " + ex.Message);
                Console.WriteLine("(ServerThread) Pressez ENTREE pour terminer");
                Console.ReadLine();
                return;
            }

            HttpListenerContext context;
            HttpListenerRequest request;

            log("(ServerThread) Serveur en écoute sur le port " + listeningPort + " ...");

            while (true)
            {
                try
                {
                    context = listener.GetContext();
                    request = context.Request;

                    if (request.RawUrl.Equals("/send_data/"))
                    {
                        RequestProcessor requestProcessor = new RequestProcessor();
                        requestProcessor.setContext(context);
                        requestProcessor.setRequest(request);
                        requestProcessor.setLogger(logger);
                        //log("(ServerThread) Client IP = " + request.RemoteEndPoint.Address);

                        Thread requestProcessorThread = new Thread(new ThreadStart(requestProcessor.RequestProcessorThread));
                        requestProcessorThread.Start();
                    }
                    //listener.Stop();
                }
                catch (Exception ex)
                {
                    log("Erreur générale : " + ex.Message);
                }
            } // fin du while(true)

        }

        private void log(string str)
        {
            logger.log(str);
        }

    }

    internal class Logger
    {
        private TextBox txtLog;
        public void setTxtLog(TextBox textBox)
        {
            this.txtLog = textBox;
        }
        public void log(string str)
        {
            try
            {
                txtLog.Invoke((MethodInvoker)delegate
                {
                    txtLog.AppendText(str + "\r\n");
                    txtLog.SelectionStart = txtLog.Text.Length;
                    txtLog.ScrollToCaret();
                });
            }
            catch (Exception)
            {
                try
                {
                    txtLog.Invoke((MethodInvoker)delegate
                    {
                        txtLog.Clear();
                    });
                }
                catch(Exception)
                {

                }

            }
        }
    }

    internal class RequestProcessor
    {
        private FileLogger fileLogger = new FileLogger();

        private Logger logger;
        public void setLogger(Logger logger_)
        {
            this.logger = logger_;
        }
        private void log(string str)
        {
            logger.log(str);
        }
        protected HttpListenerContext context;
        public void setContext(HttpListenerContext context)
        {
            this.context = context;
        }
        protected HttpListenerRequest request;
        public void setRequest(HttpListenerRequest request)
        {
            this.request = request;
        }
        HttpListenerResponse response;
        Stream output;

        //List<Rate> lstRates = new List<Rate>();

        DateTime dateTime;// = DateTime.Parse(strtab[0]);
        long mt5TickCount;// = Int32.Parse(strtab[1]);
        string instrument;// = strtab[2];
        double bid;// = Double.Parse(strtab[3].Replace(".", ","));
        double ask;// = Double.Parse(strtab[4].Replace(".", ","));

        public void RequestProcessorThread()
        {
            //log("Request method = " + request.HttpMethod);
            Stream input = request.InputStream;
            StreamReader streamReader = new StreamReader(input);
            string line = "";
            while (!streamReader.EndOfStream)
            {
                line = streamReader.ReadLine();
                log(line);
                string[] strtab = line.Split(';');
                //Rate rate = new Rate(DateTime.Parse(strtab[0]), Int32.Parse(strtab[1]), strtab[2], Double.Parse(strtab[3].Replace(".",",")), Double.Parse(strtab[4].Replace(".",",")));
                dateTime = DateTime.Parse(strtab[0]);
                mt5TickCount = Int32.Parse(strtab[1]);
                instrument = strtab[2];
                bid = Double.Parse(strtab[3].Replace(".", ","));
                ask = Double.Parse(strtab[4].Replace(".", ","));
                //Rate rate = new Rate(DateTime.Parse(strtab[0]), DateTime.Now.Ticks, strtab[2], Double.Parse(strtab[3].Replace(".", ",")), Double.Parse(strtab[4].Replace(".", ",")));
                //lstRates.Add(rate);
                fileLogger.logToFile(dateTime.ToString() + ";" + mt5TickCount + ";" + instrument + ";" + bid + ";" + ask);
            }
            streamReader.Close();
            input.Close();

            // Ici répondre au client
            response = context.Response;
            string responseString = "OK";
            byte[] buffer = Encoding.UTF8.GetBytes(responseString);
            response.ContentLength64 = buffer.Length;
            output = response.OutputStream;
            output.Write(buffer, 0, buffer.Length);
            output.Flush();
            output.Close();
        }

    }

    internal class Rate
    {
        public DateTime dateTime;
        public long tickCount;
        public string instrument;
        public double bid;
        public double ask;
        public Rate(DateTime dateTime_, long tickCount_, string instrument_, double bid_, double ask_)
        {
            dateTime = dateTime_;
            tickCount = tickCount_;
            instrument = instrument_;
            bid = bid_;
            ask = ask_;
        }
    }

    internal class FileLogger
    {
        public void logToFile(string str)
        {
            DateTime dt = DateTime.Now;
            string timestamp = dt.Year.ToString("D4") + dt.Month.ToString("D2") + dt.Day.ToString("D2");
            string workingDirDoc = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string pathToFile = workingDirDoc + @"\\" + timestamp +"_fx_rates.csv";
            FileStream fs = null;
            StreamWriter sw = null;
            try
            {
                fs = new FileStream(pathToFile, FileMode.Append);
                sw = new StreamWriter(fs);
                sw.WriteLine(str);
                sw.Close();
                fs.Close();
            }
            catch (Exception)
            {
                try { sw.Close(); } catch (Exception) { }
                try { fs.Close(); } catch (Exception) { }
            }
        }
    }
}
